/*
    Assignment 05
*/

$(document).ready(function () {
    // your code here

});


